<!DOCTYPE html>
<html lang="en">
<head>
  <title>Welcom To Admin Dashboard </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <style type="text/css">
    span{
      color: red;
    }
  </style>
</head>
<body>

<div class="container-fluid">
  <div class="container">
  	<h1>List Of All Users </h1>
  	<div class="row">
  		<div class="col-sm-12">
  			<table class="table table-bordered table-hover">
	    	    <thead>
	    	        <tr>
	    	        	<th>ID</th>
	      				<th>Firstname</th>
        			    <th>Lastname</th>
        			    <th>Email</th>
        			    <th>CNIC</th>
        			    <th>Phone Number</th>
        			    <th>Image Upload</th>
        			    <th>Address</th>
        			    <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                	<?php 

                	include 'db.php';
                	$sql = "SELECT * FROM users" ;
                    $result = mysqli_query($conn,$sql) ;
                      if (mysqli_num_rows($result) > 0) {
                      	while ($row = mysqli_fetch_assoc($result)) { ?>
                      		<tr>
                      			<td><?php echo $row['id'] ;?></td>
                      			<td><?php echo $row['fname'] ;?></td>
                      			<td><?php echo $row['lname'] ;?></td>
                      			<td><?php echo $row['email'] ;?></td>
                      			<td><?php echo $row['cnic'] ;?></td>
                      			<td><?php echo $row['phone'] ;?></td>
                      			<td><img src="<?php echo $row['img'] ;?>" width="50px" ></td>
                      			<td><?php echo $row['address'] ;?></td>
                      			<td><a href="edit.php/<?php echo $row['id']?>" class="btn btn-success">Edit</a> | <a href=" delete.php/<?php echo $row['id']?>" class="btn btn-danger">	Delete</a></td>
                      		</tr>

                      	<?php }
                      }


                	?>
                <tbody>
  		</div>
  	</div>
  </div>
</div>
</body>
</html>