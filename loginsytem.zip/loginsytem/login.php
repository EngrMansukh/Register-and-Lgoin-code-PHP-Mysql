
<?php 

if(isset($_POST['submit'])) {
  
  $email =$_POST['email'];
   $cnic = $_POST['cnic'];

  if($email==""){
    $emailErr = "Required Field " ;
  }
  elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
     $emailErr = "Requirred xx@yahoo.com" ;
  }

 /* Enter User CNIC Number */

  if($cnic==""){
    $cnicErr = "Required Field " ;
  }
  elseif (!preg_match("/^[0-9+]{5}-[0-9+]{7}-[0-9]{1}$/",$cnic)) {
  $cnicErr = "Enter xxxxx-xxxxxxx-x !";
}
  if(empty($emailErr) && empty($cnicErr)){
include 'db.php';
$sql = "SELECT * FROM users where email ='$email' && cnic = '$cnic'" ;

$result = mysqli_query($conn,$sql) ;

if (mysqli_num_rows($result) > 0) {
	while ($row = mysqli_fetch_assoc($result)) {
		 if($row['status']=="1"){
			header("location:admindashboard.php");
		} else{
			header("location:userdashboard.php");
		}
    
  }
    
} else {
    header("location:login.php");
}

}
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <title>Registeration Form</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <style type="text/css">
    span{
      color: red;
    }
  </style>
</head>
<body>

<div class="container">
  
  <div class="row">
    <div class="col-sm-3">
    </div>
    <div class="col-sm-6">
      <div class="register">
        <h1>Sign In</h1><br/>
       <?php if(isset($datainsert)){ echo "<h2>".$datainsert."</h2>";}?>
        <div class="row">
          <form action="<?php echo$_SERVER['PHP_SELF']; ?>" method="post"  enctype="multipart/form-data">
          <div class="col-sm-12">
            <div class="form-group">
              <label for="email">Enter Email</label> 
             <span><?php if(isset($emailErr)){ echo $emailErr;} ?> </span>
              <input class="form-control" id="email" type="text" class="form-control" name="email">
            </div>
          </div>
          <div class="col-sm-12">
             <div class="form-group">
                <label for="cnic">Enter CNIC Number</label>
                <span><?php if(isset($cnicErr)){ echo $cnicErr;} ?> </span>
                <input class="form-control" id="cnic" type="text" class="form-control" name="cnic">
              </div>
          </div>
         
            
          <input type="submit" name="submit" value="Submit Now" class="btn btn-success">
          <a href="resgister.php"   class="btn btn-primary">Sign Up </a>
          </form>
        </div>
      </div>
    </div>
    <div class="col-sm-3">
    </div>
  </div>
  

  
</div>
</body>
</html>



