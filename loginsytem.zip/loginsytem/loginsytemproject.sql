-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 26, 2019 at 09:58 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `loginsytemproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(12) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `cnic` varchar(55) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `img` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `status` int(12) NOT NULL DEFAULT 2
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `email`, `cnic`, `phone`, `img`, `address`, `status`) VALUES
(1, 'Mansukh', 'Malhi', 'developer.malhi13@gmail.com', '44402-5779755-1', '03490217795', 'uploads/EC-council (1).jpg', 'Karachi is ', 1),
(3, 'DolaT', 'Kumar', 'dk@yahoo.com', '44201-5779755-1', '03440217795', 'uploads/birtish.jpg', 'Multan', 2),
(4, 'Kiran', 'Kumari', 'kiran@yahoo.com', '44402-5479755-1', '03490214356', 'uploads/exin-logo-1.jpg', 'Im living karachi', 2),
(6, 'Kiran', 'Kumari', 'kiranw@yahoo.com', '44432-5479755-1', '03493214356', 'uploads/exin-logo-1.jpg', 'Im living karachi', 0),
(7, 'Kavi', 'Kumar', 'kk@yahoo.com', '44402-5473755-1', '03420234356', 'uploads/mcsa-slide.jpg', 'Today is a Day of Karachi', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uemail` (`email`),
  ADD UNIQUE KEY `ucnic` (`cnic`),
  ADD UNIQUE KEY `uphone` (`phone`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
