<?php 
if(isset($_POST['submit'])) {
  
   $fname = $_POST['fname'] ;
   $lname = $_POST['lname'];
   $email =$_POST['email'];
   $cnic =$_POST['cnic'] ;
   $phone =$_POST['phone'];
   $img_name =$_FILES['img']['name'] ;
  // print_r($img_name);die;
   $img_temp =$_FILES['img']['tmp_name'];
   $address =$_POST['address'] ;
   $upload_folder = "uploads/";
  // print_r($upload_folder);die;
  $upload_folder_img = move_uploaded_file($img_temp, $upload_folder);
$imageFileType = strtolower(pathinfo($img_name,PATHINFO_EXTENSION));
  // /print_r($upload_folder_img);die;



 /* Enter User First Name */
  if($fname=="") {

    $fnameErr = "Required Field " ;
  }
  elseif (!preg_match("/^[a-zA-Z ]*$/",$fname)) {
    $fnameErr = "Only Characters Required  " ;
  }


 /* Enter User Last Name */

  if($lname==""){
    $lnameErr = "Required Field " ;
  }
  elseif (!preg_match("/^[a-zA-Z ]*$/",$lname)) {
    $lnameErr = "Only Characters Required  " ;
  }


   /* Enter User Email Name */

  if($email==""){
    $emailErr = "Required Field " ;
  }
  elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
     $emailErr = "Requirred xx@yahoo.com" ;
  }

 /* Enter User CNIC Number */

  if($cnic==""){
    $cnicErr = "Required Field " ;
  }
  elseif (!preg_match("/^[0-9+]{5}-[0-9+]{7}-[0-9]{1}$/",$cnic)) {
  $cnicErr = "Enter xxxxx-xxxxxxx-x !";
}


/* Enter User  Phone Number **/

   if($phone==""){
    $phoneErr = "Required Field " ;
  }
  elseif(!preg_match('/^[0-9]{11}+$/', $phone)){
    $phoneErr = "valid format required";
  }

  /* Enter User Img */

  if($img_name==""){
    $img_nameErr ="Required Field";
  }
  elseif (file_exists($img_name)) {
   $img_nameErr =  "Sorry, file already exists.";
    
}
  elseif($_FILES["img"]["size"] > 500000) {
    $img_nameErr = "Sorry, your file is too large.";
}
elseif($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    $img_nameErr = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
}



  /* Enter User Address */

  if($address==""){
    $addressErr ="Required Field";
  }


  if(empty($fnameErr) && empty($lnameErr) && empty($emailErr) && empty($cnicErr) && empty($phoneErr)
   && empty($img_nameErr) && empty($addressErr)){

    include 'db.php';
   $sql = "INSERT INTO users VALUES('','$fname','$lname','$email','$cnic','$phone','$upload_folder','$address','2')";
  $result = mysqli_query($conn,$sql);
   if(!($result)){
    echo "Error".$sql .mysqli_error($conn);
   }else{
    $datainsert = "Data Inserted SuccessFully " ;
   }

  }


}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Registeration Form</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <style type="text/css">
    span{
      color: red;
    }
  </style>
</head>
<body>

<div class="container">
  
  <div class="row">
    <div class="col-sm-1">
    </div>
    <div class="col-sm-10">
      <div class="register">
        <h1>Register Now</h1><br/>
       <?php if(isset($datainsert)){ echo "<h2>".$datainsert."</h2>";}?>
        <div class="row">
          <form action="<?php echo$_SERVER['PHP_SELF']; ?>" method="post"  enctype="multipart/form-data">
          <div class="col-sm-5">
            <div class="form-group">
              <label for="fname">Enter First Name</label> 
             <span><?php if(isset($fnameErr)){ echo $fnameErr;} ?> </span>
              <input class="form-control" id="fname" type="text" class="form-control" name="fname">
            </div>
          </div>
          <div class="col-sm-5">
             <div class="form-group">
                <label for="lname">Enter Last Name</label>
                <span><?php if(isset($lnameErr)){ echo $lnameErr;} ?> </span>
                <input class="form-control" id="lname" type="text" class="form-control" name="lname">
              </div>
          </div>
         
            <div class="col-sm-5">
             <div class="form-group">
                <label for="email">Enter Email</label>
                <span><?php if(isset($emailErr)){ echo $emailErr;} ?> </span>
                <input class="form-control" id="email" type="text" class="form-control" name="email">
              </div>
            </div>
            <div class="col-sm-5">
             <div class="form-group">
                <label for="cnic">Enter CNIC Number</label>
                <span><?php if(isset($cnicErr)){ echo $cnicErr;} ?> </span>
                <input class="form-control" id="cnic" type="text" class="form-control" name="cnic">
              </div>
            </div>
            <div class="col-sm-5">
             <div class="form-group">
                <label for="phone">Enter Phone Number</label>
                <span><?php if(isset($phoneErr)){ echo $phoneErr;} ?> </span>
                <input class="form-control" id="phone" type="text" class="form-control" name="phone">
              </div>
            </div>
            <div class="col-sm-5">
             <div class="form-group">
                <label for="img">Upload Your Image</label>
                <span><?php if(isset($img_nameErr)){ echo $img_nameErr;} ?> </span>
                <input class="form-control" id="img" type="file" class="form-control" name="img">
              </div>
            </div>
            <div class="col-sm-10">
             <div class="form-group">
                <label for="cnic">Enter Address </label>
                <span><?php if(isset($addressErr)){ echo $addressErr;} ?> </span>
                <textarea name="address" cols="3" class="form-control"></textarea>
              </div>
            </div>

          </div>
          <input type="submit" name="submit" value="Submit Now" class="btn btn-success">
          <a href="login.php"   class="btn btn-primary">Sign In </a>
          </form>
        </div>
      </div>
    </div>
    <div class="col-sm-1">
    </div>
  </div>
  

  
</div>
</body>
</html>



