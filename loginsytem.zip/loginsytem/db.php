<?php 

$serverName = "localhost" ;
$userName = "root";
$pass = "";
$dbName = "loginsytemproject";

$conn = mysqli_connect($serverName,$userName,$pass,$dbName);

if(!$conn){
	die("Connection failed: " . mysqli_connect_error());
}



?>